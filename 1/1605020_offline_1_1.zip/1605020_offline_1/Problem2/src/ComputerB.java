public class ComputerB extends Computer
{
    public ComputerB()
    {
        name = "ComputerB";

        resolution = "350x250";

        CPU = "CPU_B";

        MMU = "MMU_B";
    }


}
