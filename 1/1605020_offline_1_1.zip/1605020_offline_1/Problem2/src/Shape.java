public interface Shape
{
    double perimeter();
    double surfaceArea();
}
