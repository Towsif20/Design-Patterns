public class ComputerC extends Computer
{
    public ComputerC()
    {
        name = "ComputerC";

        resolution = "550x430";

        CPU = "CPU_C";

        MMU = "MMU_C";
    }
}
