public class ComputerA extends Computer
{
    public ComputerA()
    {
        name = "ComputerA";

        resolution = "200x200";

        CPU = "CPU_A";

        MMU = "MMU_A";
    }


}
