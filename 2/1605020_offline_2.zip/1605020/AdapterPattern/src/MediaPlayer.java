public interface MediaPlayer
{
    void play(Media media);
}
