public interface AdvancedMediaPlayer
{
    void playVlc(Media media);
    void playMp4(Media media);
    void playFlv(Media media);
}
