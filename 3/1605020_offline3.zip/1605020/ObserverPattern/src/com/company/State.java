package com.company;

public class State
{
    //OPERATIONAL("operatioanl"), PARTIALLY_DOWN("partially down"), FULLY_DOWN("fully down");

    public final static String OPERATIONAL = "operational";
    public final static String PARTIALLY_DOWN = "partially down";
    public final static String FULLY_DOWN = "fully down";
}
