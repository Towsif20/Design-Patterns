package com.company;

public interface User
{
    void notify(String message);
}
